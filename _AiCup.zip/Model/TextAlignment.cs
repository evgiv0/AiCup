namespace AiCup2019.Model
{
    public enum TextAlignment
    {
        Left = 0,
        Center = 1,
        Right = 2,
    }
}
