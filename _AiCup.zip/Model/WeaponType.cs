namespace AiCup2019.Model
{
    public enum WeaponType
    {
        Pistol = 0,
        AssaultRifle = 1,
        RocketLauncher = 2,
    }
}
