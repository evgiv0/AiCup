namespace AiCup2019.Model
{
    public enum MineState
    {
        Preparing = 0,
        Idle = 1,
        Triggered = 2,
        Exploded = 3,
    }
}
