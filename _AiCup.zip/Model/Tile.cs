namespace AiCup2019.Model
{
    public enum Tile
    {
        Empty = 0,
        Wall = 1,
        Platform = 2,
        Ladder = 3,
        JumpPad = 4,
    }
}
