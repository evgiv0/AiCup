﻿namespace AiCup2019
{
    public class AIHelper
    {
        
    }
}