﻿public enum Purpose
{
    Heal = 0,
    Enemy = 1,
    Home = 2,
    BestWeapon = 3,
    NearestWeapon = 4,
    NearestNotBazuka = 5
}